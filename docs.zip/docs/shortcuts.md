# Keyboard Shortcuts

Modus includes default shortcuts for its main modeling tools and menus.

Shortcuts may depend on:

- Object Mode or Edit Mode
- the active editor
- the current selection
- the enabled Modus components
- user keymap changes

You can inspect, change, disable, or restore registered shortcuts in:

**Edit → Preferences → Add-ons → Modus → Keymaps**

# Default Shortcuts

## Object Mode

| Shortcut | Tool | Description |
|---|---|---|
| `Shift + Q` | Modus Menu | Opens the Modus quick menu in Object Mode. |
| `Alt + Q` | Quick Boolean | Opens the Quick Boolean tool. |
| `Ctrl + F` | Nested Isolation | Isolates the selected object while supporting nested isolation levels. |

## Edit Mode

| Shortcut | Tool | Description |
|---|---|---|
| `Shift + Q` | Modus Menu | Opens the Modus quick menu in Edit Mode. |
| `Shift + 1` | Merge to Last | Merges the selected mesh elements to the active or last-selected element. |
| `Alt + 1` | Merge to Center | Merges the selected mesh elements to their center. |
| `Shift + 2` | Assign Active Edge Weight | Assigns the active edge-weight value to the selected edges. |
| `Alt + 2` | Clear Active Edge Weight | Clears the active edge-weight value from the selected edges. |
| `Shift + 3` | Clean Up | Opens or runs the Modus mesh cleanup tool. |
| `Alt + R` | Loop Rotate | Rotates the selected loop. |
| `Shift + Alt + R` | Force Loop | Forces a loop through the selected topology. |
| `Alt + X` | Symmetrize | Opens the Modus symmetrize tool. |

!!! note
    Modus shortcuts are context-sensitive. A shortcut registered for Edit Mode will not run in Object Mode, and vice versa.

## Changing a Shortcut

1. Open **Edit → Preferences**.
2. Open **Add-ons**.
3. Locate **Modus**.
4. Expand **Keymaps**.
5. Find the shortcut you want to change.
6. Click the current key combination and enter a new one.

Shortcut changes are included in Modus persistent settings.

## Disabling a Shortcut

To disable a Modus shortcut without removing the extension:

1. Open the Modus **Keymaps** section.
2. Locate the shortcut.
3. Disable its checkbox.

This is useful when another extension uses the same key combination.

## Shortcut Conflicts

Some shortcuts may overlap with Blender defaults or other modeling extensions.

Potentially common conflicts include:

- `Alt + Q`
- `Alt + X`
- `Alt + R`
- `Shift + Q`

When a shortcut does not run:

1. Confirm that Blender is in the correct mode.
2. Confirm that the mouse is over the 3D Viewport.
3. Check the Modus keymap entry.
4. Search Blender's Keymap preferences for another command using the same shortcut.
5. Change or disable one of the conflicting entries.
